//
// Created by 50450 on 2019/6/4.
//

#include <iostream>
#include "BattleShip.h"

int main(int argc, char** argv){
    int seed;
    if(argc == 2){
        seed = -999;
    }
    else{
        seed = std::stoi(argv[2]);
    }
    BattleShip::BattleShip game (argv[1],seed);
    game.playGame();
}