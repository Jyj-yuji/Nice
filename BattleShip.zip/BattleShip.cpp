//
// Created by 50450 on 2019/6/4.
//
#include "BattleShip.h"
#include "Player.h"
#include "HumanPlayer.h"
#include "CheatingAi.h"
#include "RandomAi.h"
#include "HuntDestroyAi.h"
//#include "AiPlayer.h"
#include "Move.h"

namespace BattleShip{

    BattleShip::~BattleShip() {

    }

    BattleShip::BattleShip(const std::string& fileName, const int& seed){
        AiPlayer::seed_random_number_generator(seed);
        // Ask: what type of game?
        BattleShip::seed = seed;
        playerTurn = 0;
        //Initialize player names based on type of game

        //Reading from the file to get info needed to initialize the players.
        std::ifstream inFile;
        std::string line;
        inFile.open(fileName);
        int i = 0;
        if (!inFile) {
            std::cerr << "Unable to open file datafile.txt";
            exit(1);   // call system to stop
        }
        while(inFile){
            if(i == 0) {
                inFile >> row;
                inFile >> col;
                inFile >> numOfShip;
                i++;
            }
            char shipName;
            int shipLen;
            //std::cout<<line<<std::endl;
            inFile>>shipName;
            inFile>>shipLen;
            shipList.emplace(shipName, shipLen);
        }

        addPlayerToGame();
        setOpponents();
//        if(inFile){
//        for(int i =0; i<= 1 ; i++) {
//            getline(inFile, line);
//            dim = std::stoi(line);
//        }
//        getline(inFile, line);
//        numOfShip = std::stoi(line);
//        playerTurn = 0;
//        while(getline(inFile,line)){
//                std::cout<<line<<std::endl;
//                std::map<char, int> shipList;
//                shipList.emplace(line.at(0), line.at(2));
//                //put the ships into the list of ships a player owns
//        }
//        }
        inFile.close();
        //all things initialized
    }

    void BattleShip::playGame() {
        playerTurn = 0;

        while(true){
            //displayBoard();

            //Ask for the move here!
            Move move = getCurrentPlayerMove();
            //unpdate both the firing board of current player and placement board of opponent here!
            move.make(getOpponent());

            //displayBoard();
            if(gameOver()){
                declareResult();
                break;
            }
            switchTurn();
        }
        //std::cout<<"Game has ended"<<std::endl;
        }



    void BattleShip::addPlayerToGame() {
            int playerType;
            std::cout << "What type of game do you want to play?" << std::endl;
            std::cout << "1. Human vs Human" << std::endl;
            std::cout << "2. Human vs AI" << std::endl;
            std::cout << "3. AI vs AI" << std::endl;
            std::cout << "Your choice: " ;
            std::cin>>playerType;
            if (playerType == 1){
                players.push_back(std::make_unique<HumanPlayer>(shipList,row,col,playerTurn));
                switchTurn();
                players.push_back(std::make_unique<HumanPlayer>(shipList,row,col,playerTurn));
                switchTurn();
                gameType = 1;
                std::cin.clear();
                std::cin.ignore();
            }
            else if(playerType == 2){

                players.push_back(std::make_unique<HumanPlayer>(shipList,row,col,playerTurn));
                switchTurn();

                //Choose type of Ai here!! Need to construct
                determineAiPlayer();
                switchTurn();
                gameType = 2;
                std::cin.clear();
                std::cin.ignore();
            }
            else{
                determineAiPlayer();
                switchTurn();
                determineAiPlayer();
                switchTurn();
                gameType = 3;
                std::cin.clear();
                std::cin.ignore();
            }
    }

    void BattleShip::determineAiPlayer() {
        int AiChoice = 99;
        std::cout<<"What AI do you want?"<<std::endl;
        std::cout<<"1. Cheating AI"<<std::endl;
        std::cout<<"2. Random AI"<<std::endl;
        std::cout<<"3. Hunt Destroy AI"<<std::endl;
        std::cout<<"Your choice: ";
        std::cin>> AiChoice;
        if(AiChoice == 1){
            players.push_back(std::make_unique<CheatingAi>(shipList,row, col, playerTurn,seed));
        }
        else if(AiChoice == 2){
            players.push_back(std::make_unique<RandomAi>(shipList,row, col, playerTurn,seed));
        }
        else if(AiChoice == 3){
            players.push_back(std::make_unique<HuntDestroyAi>(shipList,row, col, playerTurn,seed));
        }
        else{
            std::cout<<"Choose a valid Ai!"<<std::endl;
        }
    }

    void BattleShip::switchTurn() {
        playerTurn = (playerTurn + 1)%2;
    }

    void BattleShip::displayBoard() {
        std::cout<<players.at(playerTurn)->getName()<<"'s Firing Board"<<std::endl;
        getCurrentPlayer().getFiringBoard().display();
        std::cout<<players.at(playerTurn)->getName()<<"'s Placement Board"<<std::endl;
        getCurrentPlayer().getPlacementBoard().display();
    }

    bool BattleShip::gameOver() {
        return getOpponent().getPlacementBoard().noMoreShip();
    }

    Player &BattleShip::getCurrentPlayer() {
        return *players.at(playerTurn);
    }

    Move BattleShip::getCurrentPlayerMove() {
        return getCurrentPlayer().getMove(getCurrentPlayer().getFiringBoard());
    }

    Player &BattleShip::getOpponent() {
        return *players.at((playerTurn+1)%2);
    }

    void BattleShip::declareResult() {
        std::cout<<getCurrentPlayer().getName()<<" won the game!"<<std::endl;
    }

    void BattleShip::setOpponents() {
        players.at(0)->setOpponent(*(players.at(1)));
        players.at(1)->setOpponent(*(players.at(0)));
    }

//    const Board &BattleShip::getOpponentsBoard() {
//        return getOpponent().getPlacementBoard();
//    }

}




