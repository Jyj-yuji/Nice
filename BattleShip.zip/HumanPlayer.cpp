//
// Created by 50450 on 2019/6/5.
//

#include "HumanPlayer.h"
#include "Move.h"


namespace BattleShip {


    HumanPlayer::HumanPlayer(const std::map<char, int>& ships, const int& row,const int& col, int& currentPlayer) :
    Player(ships, row, col) {
        playerType = 0;
        initializeName(currentPlayer);
        placeShips();
    }

    void HumanPlayer::initializeName(int &currentPlayer) {
        int a;
        std::string line;
        if (currentPlayer == 0) {
            a = 1;
        } else {
            a = 2;
        };
        std::cout << "Player " << a << " please enter your name: " ;
        std::cin>>line;
        setName(line);
    }

    void HumanPlayer::placeShips() {
        std::map<char, int>::iterator it;
        getPlacementBoard().display();
        for (it = ships.begin(); it != ships.end(); it++) {
            std::string hV;
            int shipLen = it->second;
            char piece = it->first;
            while(hV.length() != 1) {
                hV = "";
                std::cout << name << ", do you want to place " << it->first << " horizontally or vertically?"
                          << std::endl;
                std::cout<<"Enter h for horizontal or v for vertical"<<std::endl;
                std::cout<<"Your choice: ";
                std::cin>>hV;
                if(hV != "v"&& hV != "h"&& hV != "V"&& hV != "h"){
                    hV = "";
                    continue;
                }
            }
            int row = 99;
            int col = 99;
            int check = 0;
            std::string extra;
            while(check == 0){
                std::cout<<name<<", enter the row and column you want to place "<<it->first<<", which is "<<
                shipLen<<" long, at with a space in between row and col: ";
                std::cin>>row;
                std::cin>>col;
                if(!extra.empty()){
                    continue;
                }
//                getline(std::cin, pos);
//                if(pos.length() != 3){
//                  continue;
//                }
//                row = pos.at(0);
//                col = pos.at(2);
                if(placementBoard.checkInBoundsForShip(hV,shipLen,row,col))
                {
                placementBoard.setShip(hV,shipLen,piece, row, col);
                    getPlacementBoard().display();
                check = 1;
                }
            }
        }
    }

    Move HumanPlayer::getMove(const Board &board) {
        Move PlayerMove(*this);
        do{
            parseUserInput(PlayerMove);
        }while(!PlayerMove.isValid(board));
        return PlayerMove;
    }

    void HumanPlayer::parseUserInput(Move &playerMove) const {
        bool parsedSuccesfully = true;
        std::cout<<getName()<<"'s Firing Board"<<std::endl;
        firingBoard.display();
        std::cout<<std::endl;
        std::cout<<std::endl;
        std::cout<<getName()<<"'s Placement Board"<<std::endl;
        placementBoard.display();
        do{
            std::cout<<getName()<<", where would you like to fire?"<<std::endl;
            std::cout<<"Enter your attack coordinate in the form row col: ";
            std::string line;
            std::getline(std::cin, line);
            std::stringstream userIn(line);
            userIn>> playerMove.getRow()>>playerMove.getCol();

            parsedSuccesfully = parsedSuccesfully && static_cast<bool>(userIn);
            std::string leftovers;
            userIn>>leftovers;

            parsedSuccesfully = parsedSuccesfully && !userIn;
        }while(!parsedSuccesfully);
    }


}