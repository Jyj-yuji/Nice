//
// Created by 50450 on 2019/6/10.
//

#ifndef BATTLESHIP_CHEATINGAI_H
#define BATTLESHIP_CHEATINGAI_H

#include "AiPlayer.h"

namespace BattleShip {
    class CheatingAi : public AiPlayer {
    public:
        CheatingAi(const std::map<char, int>& ships, const int& row, const int& col, int& currentPlayer,int& seed);
        Move getMove(const Board& board) override;

    private:

    };
}
#endif //BATTLESHIP_CHEATINGAI_H
