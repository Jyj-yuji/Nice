//
// Created by 50450 on 2019/6/10.
//

#ifndef BATTLESHIP_HUNTDESTROYAI_H
#define BATTLESHIP_HUNTDESTROYAI_H

#include "RandomAi.h"

namespace BattleShip{

    class HuntDestroyAi : public RandomAi{
    public:
        HuntDestroyAi(const std::map<char, int> &ships, const int &row, const int &col, int &currentPlayer,int& seed);
        std::vector<std::vector<int>>& getPriorityList();
        Move getMove(const Board& board) override;
        void addToPriorityList(int row, int col);
    private:
        std::vector<std::vector<int>> priorityList;

    };

}


#endif //BATTLESHIP_HUNTDESTROYAI_H
