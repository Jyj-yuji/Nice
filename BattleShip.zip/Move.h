//
// Created by 50450 on 2019/6/4.
//

#ifndef BATTLESHIP_MOVE_H
#define BATTLESHIP_MOVE_H
#include <sstream>
#include "Board.h"
#include "Player.h"

namespace BattleShip{

    class Move{

    public:
        Move(Player& maker);
        void parseInput(std::stringstream & input);
        bool isValid(const Board& board) const;
        void make(Player& Opponent);
        int& getRow();
        int& getCol();
        void shipHit(const char& piece, Player& opponent);
        bool shipSunk(const char & piece, Player& opponent);
        void setParse();
    private:
        Player& maker;
        int row, col;
        bool parsedSuccessfully;
    };
}

#endif //BATTLESHIP_MOVE_H
