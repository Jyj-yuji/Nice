#!/usr/bin/env bash
sudo apt-get update
sudo apt-get install -y valgrind libncurses5-dev libncursesw5-dev