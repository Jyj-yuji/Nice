//
// Created by 50450 on 2019/6/5.
//

#ifndef BATTLESHIP_HUMANPLAYER_H
#define BATTLESHIP_HUMANPLAYER_H

#include "Player.h"

namespace BattleShip {

    class HumanPlayer : public Player {
    public:
        //HumanPlayer();
        HumanPlayer(const std::map<char, int>& ships, const int& row,const int& col, int& currentPlayer);
        void initializeName(int& currentPlayer) override;
        void placeShips() override ;
        Move getMove(const Board& board) override;

    protected:
        virtual void parseUserInput(Move& playerMove) const;

    };
}

#endif //BATTLESHIP_HUMANPLAYER_H
