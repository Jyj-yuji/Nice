//
// Created by 50450 on 2019/6/4.
//

#ifndef BATTLESHIP_PLAYER_H
#define BATTLESHIP_PLAYER_H

#include <vector>
#include <string>
#include <map>
#include <memory>
#include "Board.h"

namespace BattleShip {
    class Move;
    class Player {
    public:
        //Player();

        Player(const std::map<char, int>& ships, const int& row, const int& col);

        virtual void placeShips() = 0;

        virtual void initializeName(int& currentPlayer);

        virtual void setName(std::string newName);

        const int& getPlayerType();
        virtual const std::string getName() const;

        virtual Board &getPlacementBoard();
        virtual Board &getFiringBoard();
        virtual std::map<char, int>& getList();
        virtual Player& getOpponent();
        virtual void setOpponent(Player& oppo);
        virtual Move getMove(const Board& board) = 0;


    protected:
        std::string name;
        std::map<char, int> ships;
        BattleShip::Board placementBoard;
        BattleShip::Board firingBoard;
        int playerType;  // 0 = Human, 1 = Ai
        Player* opponent;
    };


}
#endif //BATTLESHIP_PLAYER_H
