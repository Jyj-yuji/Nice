//
// Created by mfbut on 3/9/2019.
//

#ifndef BATTLESHIP_AIPLAYER_H
#define BATTLESHIP_AIPLAYER_H
#include <random>
#include "Player.h"

namespace BattleShip {

class AiPlayer : public Player {
 public:
    AiPlayer(const std::map<char, int>& ships, const int& row, const int& col,int& currentPlayer, int& seed);
  static void seed_random_number_generator(int seed);
  virtual void placeShips() override;
  virtual void initializeName(int& currentPlayer) override;
  virtual void generatePossiblePoints(const int& row, const int& col);
  virtual Move getMove(const Board& board) override;
    std::vector<std::vector<int>>& getpossiblePoints();


 protected:
  static std::mt19937 randomNumberGenerator;

 private:
  static int nextAiId;
  const int aiId;
  std::vector<std::vector<int>> possiblePoints;
  int seed;
};
}
#endif //BATTLESHIP_AIPLAYER_H
