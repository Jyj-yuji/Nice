//
// Created by 50450 on 2019/6/4.
//

#include "Move.h"
#include "Board.h"
#include "Player.h"

namespace BattleShip{


    Move::Move(BattleShip::Player &maker) :
    maker(maker),row(-99),col(-99),parsedSuccessfully(false){

    }

    void Move::parseInput(std::stringstream &input) {
        parsedSuccessfully = static_cast<bool>(input);
        input >> row;
        input >> col;
        std::string leftovers;
        input >> leftovers;
        parsedSuccessfully = parsedSuccessfully && !input;
    }

    bool Move::isValid(const BattleShip::Board &board) const {
        return  board.checkInBounds(row,col) && board.checkRepeat(row,col) ;
    }

    void Move::make(Player& opponent) {
        char piece = opponent.getPlacementBoard().at(row,col);
        if(opponent.getPlacementBoard().at(row,col) == '*'){
            maker.getFiringBoard().setUnhitBoard(row,col);
            opponent.getPlacementBoard().setUnhitBoard(row,col);
            std::cout<<maker.getName()<<"'s Firing Board"<<std::endl;
            maker.getFiringBoard().display();
            std::cout<<std::endl;
            std::cout<<std::endl;
            std::cout<<maker.getName()<<"'s Placement Board"<<std::endl;
            maker.getPlacementBoard().display();
            std::cout<<"Missed."<<std::endl;
            std::cout<<std::endl;
        }
        else{
            bool sunk = false;
            shipHit(piece,opponent);
            sunk = shipSunk(piece, opponent);
            maker.getFiringBoard().setHitBoard(row,col);
            opponent.getPlacementBoard().setHitBoard(row,col);
            std::cout<<maker.getName()<<"'s Firing Board"<<std::endl;
            maker.getFiringBoard().display();
            std::cout<<std::endl;
            std::cout<<std::endl;
            std::cout<<maker.getName()<<"'s Placement Board"<<std::endl;
            maker.getPlacementBoard().display();
            std::cout<<maker.getName()<<" hit "<<opponent.getName()<<"'s "<<piece<<"!"<<std::endl;
            if(sunk){
                std::cout<<maker.getName()<<" destroyed "<<opponent.getName()<<"'s "<<piece<<"!"<<std::endl;
            }
            std::cout<<std::endl;
        }
    }

    int &Move::getRow() {
        return row;
    }

    int &Move::getCol() {
        return col;
    }

    void Move::shipHit(const char& piece, Player& opponent) {
        std::map<char, int>::iterator it;
        it = opponent.getList().find(piece);
        if (it != opponent.getList().end()){
            it->second --;
        }
    }

    bool Move::shipSunk(const char& piece, Player& opponent) {
        std::map<char, int>::iterator it;
        it = opponent.getList().find(piece);
        if(it->second == 0){
            opponent.getList().erase(it);
            return true;
        }
        return false;
    }

    void Move::setParse() {
    parsedSuccessfully = true;
    }

}