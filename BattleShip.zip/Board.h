//
// Created by 50450 on 2019/6/4.
//

#ifndef BATTLESHIP_BOARD_H
#define BATTLESHIP_BOARD_H

#include <vector>
#include <string>
#include <iostream>
#include <algorithm>

namespace BattleShip{
    class Board{
    public:
        Board(const int& row , const int& col);
        void display() const;
        char& at(int row, int col);
        const char& at(int row, int col) const;
        int& getRow();
        int& getCol();
        bool checkInBounds(const int& row, const int& col) const;
        bool checkRepeat(const int& row, const int& col) const;
        bool checkInBoundsForShip(const std::string& hV,const int& shipLen,const int& row, const int& col);
        void setShip(const std::string& hV, const int& shipLen,const char piece, const int& row, const int& col);
        bool noMoreShip();
        void setUnhitBoard(const int& row, const int& col);
        void setHitBoard(const int& row, const int& col);
    private:
        int rowLen;
        int colLen;
        std::vector<std::string> state;
    };


}
#endif //BATTLESHIP_BOARD_H
