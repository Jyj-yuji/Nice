//
// Created by 50450 on 2019/6/4.
//

#include "Board.h"

namespace BattleShip {

    BattleShip::Board::Board(const int& row, const int& col):
    rowLen(row),colLen(col), state(row, std::string(col, '*')){

    }


    void BattleShip::Board::display() const {
        std::cout<<"  ";
        for (int a = 0; a <= rowLen-1; a++){
            std::cout<<a<<" ";
        }
        std::cout<<std::endl;
        for(int i = 0 ; i <= rowLen-1; i++){
            std::cout<<i<<" ";
            for(int j =0 ; j <= colLen-1; j++){
                std::cout<<state.at(i).at(j)<<" ";
            }
            std::cout<<std::endl;
        }
    }

    char &Board::at(int row1, int col1) {
        return state.at(row1).at(col1);
    }

    int& Board::getRow() {
        return rowLen;
    }

    int& Board::getCol() {
        return colLen;
    }

    bool Board::checkInBoundsForShip(const std::string& hV,const int& shipLen,const int& row, const int& col) {
        if (hV == "h" || hV == "H"){
            for(int i = 0; i <= shipLen-1; i++){
                if(!checkInBounds(row, col + i)|| !checkRepeat(row, col + i)){
                    return false;
                }
            }
            return true;
        }
        else if(hV == "v" || hV == "V"){
            for(int i = 0; i <= shipLen-1; i++){
                if(!checkInBounds(row + i, col)|| !checkRepeat(row + i, col)){
                    return false;
                }
            }
            return true;
        }
        else{
            std::cout<<"Unexpected error in checking inbounds for shipPlacement!"<<std::endl;
            return false;
        }
    }

    void Board::setShip(const std::string &hV,const int& shipLen, const char piece,const int &rown, const int &coln) {
        if (hV == "h" || hV == "H"){
            for(int i = 0; i <= shipLen-1; i++){
                at(rown ,coln + i) =  piece;
            }
        }
        else if(hV == "v" || hV == "V"){
            for(int i = 0; i <= shipLen-1; i++){
                at(rown + i ,coln ) =  piece;
            }
        }
        else{
            std::cout<<"Unexpected error in placing the ship!"<<std::endl;
        }
    }

    bool Board::checkInBounds(const int &row0, const int &col0)const {
        return row0 >= 0 && row0 <= rowLen -1 && col0 >= 0 && col0 <= colLen-1;
    }

    bool Board::checkRepeat(const int &row0, const int &col0)const {
        if(checkInBounds(row0,col0)){
            return at(row0,col0)=='*';
        }
        return false;
    }

    bool Board::noMoreShip() {
        for(int i= 0 ; i<= rowLen-1; i++){
            for(int j= 0 ; j<= colLen-1; j++){
                if(at(i,j)!= '*'&&at(i,j)!= 'X'&&at(i,j)!='O'){
                    return false;
                }
            }
        }
        return true;
    }

    const char &Board::at(int row, int col) const {
        return state.at(row).at(col);
    }

    void Board::setUnhitBoard(const int& row, const int& col) {
        at(row, col) = 'O';
    }

    void Board::setHitBoard(const int &row, const int &col) {
        at(row, col) = 'X';
    }


}