//
// Created by 50450 on 2019/6/10.
//
#include <memory>
#include "CheatingAi.h"
#include "Move.h"
namespace BattleShip {
    Move CheatingAi::getMove(const Board &board) {
        Move PlayerMove(*this);
        int row = opponent->getPlacementBoard().getRow();
        int col = opponent->getPlacementBoard().getCol();
        for(int i=0; i<= row-1; i++){
            for(int j = 0; j<= col-1; j++){
                if(opponent->getPlacementBoard().at(i,j)!='*' && opponent->getPlacementBoard().at(i,j)!='X' &&
                        opponent->getPlacementBoard().at(i,j)!='O'){
                    PlayerMove.getRow() = i;
                    PlayerMove.getCol() = j;
                    PlayerMove.setParse();
                    return PlayerMove;
                }
            }
        }
        return PlayerMove;
    }

    CheatingAi::CheatingAi(const std::map<char, int> &ships, const int &row, const int &col, int &currentPlayer,int& seed
                           ) :AiPlayer(ships, row, col, currentPlayer,seed){
                           //CheatingAi::opponent = std::make_unique<Player>(opponent);
    }


}