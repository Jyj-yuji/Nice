//
// Created by 50450 on 2019/6/10.
//

#include "RandomAi.h"
#include "Utility.h"
#include "Move.h"

namespace BattleShip{


    RandomAi::RandomAi(const std::map<char, int> &ships, const int &row, const int &col, int &currentPlayer,int& seed) : AiPlayer(
            ships, row, col, currentPlayer, seed) {

    }

    Move RandomAi::getMove(const Board &board) {
        Move PlayerMove(*this);
        auto itr = chooseRandom(getpossiblePoints(),randomNumberGenerator);
        std::vector<int> pair = *itr;
        PlayerMove.getRow() = pair.at(0);
        PlayerMove.getCol() = pair.at(1);
        getpossiblePoints().erase(itr);
        PlayerMove.setParse();
        return PlayerMove;
    }
}
