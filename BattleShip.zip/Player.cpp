//
// Created by 50450 on 2019/6/5.
//

#include "Player.h"

namespace BattleShip {


    Player::Player(const std::map<char, int> &ships, const int &row, const int &col) :
            name("defaultName"), ships(ships), placementBoard(Board(row, col)), firingBoard(Board(row, col)),
            playerType(-1),opponent(nullptr) {

    }

    void Player::placeShips() {

    }

    void Player::initializeName(int &currentPlayer) {

    }

    void Player::setName(std::string newName) {
        name = newName;
    }

    Board &Player::getPlacementBoard() {
        return placementBoard;
    }

    Board &Player::getFiringBoard() {
        return firingBoard;
    }

    const int &Player::getPlayerType() {
        return playerType;
    }

    const std::string Player::getName() const {
        return name;
    }


    std::map<char, int> &Player::getList() {
        return ships;
    }



    Player &Player::getOpponent() {
        return *opponent;
    }

    void Player::setOpponent(Player &oppo) {
        opponent = &oppo;
    }

}