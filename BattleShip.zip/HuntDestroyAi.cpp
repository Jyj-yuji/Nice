//
// Created by 50450 on 2019/6/10.
//

#include "HuntDestroyAi.h"
#include "Move.h"
#include "Utility.h"

namespace BattleShip{


    HuntDestroyAi::HuntDestroyAi(const std::map<char, int> &ships, const int &row, const int &col, int &currentPlayer,int& seed)
            : RandomAi(ships, row, col, currentPlayer, seed) {

    }

    std::vector<std::vector<int>> &HuntDestroyAi::getPriorityList() {
        return priorityList;
    }

    Move HuntDestroyAi::getMove(const Board &board) {
        Move PlayerMove(*this);
        if(priorityList.empty()) {
            auto itr = chooseRandom(getpossiblePoints(),randomNumberGenerator);
            std::vector<int> pair = *itr;
            PlayerMove.getRow() = pair.at(0);
            PlayerMove.getCol() = pair.at(1);
            getpossiblePoints().erase(itr);

            PlayerMove.setParse();
        }
        else{
            PlayerMove.getRow() = priorityList.at(0).at(0);
            PlayerMove.getCol() = priorityList.at(0).at(1);
            PlayerMove.setParse();
            priorityList.erase(priorityList.begin());
        }

        int row = PlayerMove.getRow(), col = PlayerMove.getCol();
        if(getOpponent().getPlacementBoard().at(row,col) != '*' ){
            addToPriorityList(row,col-1);
            addToPriorityList(row-1,col);
            addToPriorityList(row,col+1);
            addToPriorityList(row+1,col);
        }

        return PlayerMove;
    }

    void HuntDestroyAi::addToPriorityList(int row, int col) {
        if(contains(std::vector<int>{row,col},getpossiblePoints())){
            priorityList.push_back({row,col});
            auto itr = std::find(getpossiblePoints().begin(),getpossiblePoints().end(),std::vector<int>{row,col});
            getpossiblePoints().erase(itr);
        }
//        if(getOpponent().getPlacementBoard().checkInBounds(row,col)&&
//                getOpponent().getPlacementBoard().checkRepeat(row,col)){
//            priorityList.push_back({row,col});
//        }
    }


}
