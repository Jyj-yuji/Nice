//
// Created by 50450 on 2019/6/4.
//

#ifndef BATTLESHIP_BATTLESHIP_H
#define BATTLESHIP_BATTLESHIP_H

#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <memory>
#include "Player.h"


namespace BattleShip {
class Move;
    class BattleShip {
    public:
        BattleShip(const std::string& fileName, const int& seed);
        void playGame();
        virtual ~BattleShip();
        void addPlayerToGame();
        void determineAiPlayer();
        void switchTurn();
        void displayBoard();
        bool gameOver();
        Move getCurrentPlayerMove();
        Player& getCurrentPlayer();
        Player& getOpponent();
        void declareResult();
        void setOpponents();
//        const Board& getOpponentsBoard();

    private:
        int gameType; // 1 = h vs h; 2 = h vs ai; 3 = ai vs ai
        std::vector<std::unique_ptr<Player>> players;
        int playerTurn;
        int row;
        int col;
        int numOfShip;
        std::map<char,int> shipList;
        int seed;
    };
}
#endif //BATTLESHIP_BATTLESHIP_H
