//
// Created by 50450 on 2019/6/10.
//

#ifndef BATTLESHIP_RANDOMAI_H
#define BATTLESHIP_RANDOMAI_H

#include "AiPlayer.h"

namespace BattleShip{

    class RandomAi: public AiPlayer{
    public:
        RandomAi(const std::map<char, int>& ships, const int& row, const int& col,int& currentPlayer,int& seed);
        virtual Move getMove(const Board& board) override;
    private:



    };

}

#endif //BATTLESHIP_RANDOMAI_H
