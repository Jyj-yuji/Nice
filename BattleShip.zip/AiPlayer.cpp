//
// Created by mfbut on 3/9/2019.
//
#include <sstream>
#include <ctime>
#include "Utility.h"
#include "AiPlayer.h"
#include "Move.h"
int BattleShip::AiPlayer::nextAiId = 1;
std::mt19937 BattleShip::AiPlayer::randomNumberGenerator((time(nullptr)));



BattleShip::AiPlayer::AiPlayer(const std::map<char, int>& ships, const int& row, const int& col, int& currentPlayer, int& seed) :
    Player(ships, row , col), aiId(AiPlayer::nextAiId),seed(seed) {
  nextAiId++;
  initializeName(currentPlayer);
  generatePossiblePoints(row,col);
  placeShips();
}


void BattleShip::AiPlayer::placeShips() {
  std::vector<char> orientation_choice{'h', 'v'};
  const int numRows = getPlacementBoard().getRow();
  const int numCols = getFiringBoard().getCol();

  //ShipPlacement placement;
    for (auto ship : ships) {
        int shipLen = ship.second;
        int i =0;
    do {
      char orientation = *chooseRandom(orientation_choice, randomNumberGenerator);
      if (orientation == 'h') {
        int rowStart = getRandInt(0, numRows - 1, randomNumberGenerator);
        int colStart = getRandInt(0, numCols - ship.second, randomNumberGenerator);
        std::string s(1,orientation);
          if(!getPlacementBoard().checkInBoundsForShip(s, shipLen,rowStart,colStart)){
              continue;
          }
          getPlacementBoard().setShip(s,shipLen,ship.first,rowStart,colStart);
          i = 1;
//        placement.rowEnd = placement.rowStart;
//        placement.colEnd = placement.colStart + ship.second - 1;
      } else {
        int rowStart = getRandInt(0, numRows - ship.second, randomNumberGenerator);
        int colStart = getRandInt(0, numCols - 1, randomNumberGenerator);
          std::string s(1,orientation);
          if(!getPlacementBoard().checkInBoundsForShip(s, shipLen,rowStart,colStart)){
              continue;
          }
          getPlacementBoard().setShip(s,shipLen,ship.first,rowStart,colStart);
          i=1;
//        placement.rowEnd = placement.rowStart + ship.second - 1;
//        placement.colEnd = placement.colStart;
      }
    }while(i == 0);
//    getBoard().AddShip(ship.first, placement);
    std::cout<<getName()<<"'s Board"<<std::endl;
    getPlacementBoard().display();
    std::cout<<std::endl;
  }
}

void BattleShip::AiPlayer::initializeName(int& currentPlayer) {
  std::stringstream name;
  name << "AI " << aiId;
  setName(name.str());
}

void BattleShip::AiPlayer::seed_random_number_generator(int seed) {
  BattleShip::AiPlayer::randomNumberGenerator.seed(seed);
}

void BattleShip::AiPlayer::generatePossiblePoints(const int& row, const int& col) {
    for(int i = 0; i<= row - 1;i++){
        for(int j = 0; j<= col-1; j++){
            possiblePoints.push_back({i,j});
        }
        }
}

std::vector<std::vector<int>> &BattleShip::AiPlayer::getpossiblePoints() {
    return possiblePoints;
}

BattleShip::Move BattleShip::AiPlayer::getMove(const BattleShip::Board &board) {
    Move PlayerMove(*this);
    return PlayerMove;
}





